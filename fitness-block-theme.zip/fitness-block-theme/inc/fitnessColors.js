const ourColors=[
    {name:"Primary Color",cls:"primaryColor",color:"#20202C"},
    {name:"Primary Button",cls:"primaryButton",color:"#FFCC00"}
]
export default ourColors